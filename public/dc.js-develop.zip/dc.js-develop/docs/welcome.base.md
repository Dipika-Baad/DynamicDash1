# dc.js

Welcome to the dc.js documentation.

The entire library is scoped under {@link dc the dc namespace}. Its child namespaces contain utilities.

A class diagram is shown below - mixins are blue and chart classes are green. (Relations between mixins are somewhat subjective.)

